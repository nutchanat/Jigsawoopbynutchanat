/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jigsawoopbynutchanat;

/**
 *
 *
 */
public class image {
 public   String[] ajimage = new String[9];
 public image(){
    this.ajimage[0]="image/aj0.png"; 
    this.ajimage[1]="image/aj1.png"; 
    this.ajimage[2]="image/aj2.png"; 
    this.ajimage[3]="image/aj3.png"; 
    this.ajimage[4]="image/aj4.png"; 
    this.ajimage[5]="image/aj5.png"; 
    this.ajimage[6]="image/aj6.png"; 
    this.ajimage[7]="image/aj7.png"; 
    this.ajimage[8]="image/aj8.png"; 
    
    
    
} 
    
}
